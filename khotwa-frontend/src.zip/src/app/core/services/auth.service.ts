import { Injectable } from '@angular/core';
import { User, UserRole } from '../models';


const MOCK_USERS: User[] = [
  {
    idUser: 1,
    nom: 'Bensalem',
    prenom: 'Karim',
    emailAddress: 'admin@khotwa.tn',
    role: 'admin'
  },
  {
    idUser: 2,
    nom: 'Trabelsi',
    prenom: 'Sara',
    emailAddress: 'sara@startup.tn',
    role: 'entrepreneur',
    startup: 'EduTech Pro',
    planType: 'FREE'
  },
  {
    idUser: 3,
    nom: 'Mansouri',
    prenom: 'Ahmed',
    emailAddress: 'ahmed@coach.tn',
    role: 'coach',
    planType: 'INSTITUTIONAL'
  },

  // 🚀 Nouvel entrepreneur 1
  {
    idUser: 4,
    nom: 'chamsi',
    prenom: 'chamsi',
    emailAddress: 'amirachamsi9@gmail.com',
    role: 'entrepreneur',
    startup: 'TechNova',
    planType: 'FREE'
  },

  // 🚀 Nouvel entrepreneur 2
  {
    idUser: 5,
    nom: 'Ben Yedder',
    prenom: 'Amine',
    emailAddress: 'amine@smartbiz.tn',
    role: 'entrepreneur',
    startup: 'SmartBiz',
    planType: 'PREMIUM'
  }
];

@Injectable({ providedIn: 'root' })
export class AuthService {
  currentUser: User | null = MOCK_USERS[0];

  get role(): UserRole | null { return this.currentUser?.role ?? null; }
  get isAdmin(): boolean { return this.currentUser?.role === 'admin'; }
  get isEntrepreneur(): boolean { return this.currentUser?.role === 'entrepreneur'; }
  get isCoach(): boolean { return this.currentUser?.role === 'coach'; }

  login(role: UserRole): void {
    this.currentUser = MOCK_USERS.find(u => u.role === role) ?? null;
  }
  logout(): void { this.currentUser = null; }

  getDefaultRoute(): string {
    const r = this.currentUser?.role;
    return r === 'admin' ? '/khotwaadmin/dashboard'
      : r === 'entrepreneur' ? '/entrepreneur/dashboard'
      : r === 'coach' ? '/coach/dashboard' : '/';
  }
  get planType(): string | null {
  return this.currentUser?.planType ?? null;
}

get hasActiveSubscription(): boolean {
  if (!this.currentUser) return false;

  // coach toujours actif
  if (this.isCoach) return true;

  // entrepreneur → dépend du plan
  return this.currentUser.planType !== 'FREE';
}
canAccess(requiredPlan: 'FREE' | 'PREMIUM' | 'INSTITUTIONAL'): boolean {
  if (!this.currentUser) return false;

  // coach → accès total
  if (this.isCoach) return true;

  const hierarchy = {
    FREE: 1,
    PREMIUM: 2,
    INSTITUTIONAL: 3
  };

  const userPlan = this.currentUser.planType ?? 'FREE';

  return hierarchy[userPlan] >= hierarchy[requiredPlan];
}
}
