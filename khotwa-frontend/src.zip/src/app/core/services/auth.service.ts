import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap, catchError, throwError } from 'rxjs';
import {
  AuthResponse,
  LoginRequest,
  RegisterRequest,
  User,
  UserResponse,
  UserRole,
  PlanType,
} from '../models/user.model';

const API_BASE = 'http://localhost:8084/khotwa/api';
const TOKEN_KEY = 'khotwa_token';
const USER_KEY  = 'khotwa_user';

@Injectable({ providedIn: 'root' })
export class AuthService {

  private _currentUser: User | null = null;

  constructor(private http: HttpClient, private router: Router) {
    // Restaure la session depuis localStorage au démarrage
    const saved = localStorage.getItem(USER_KEY);
    if (saved) {
      try { this._currentUser = JSON.parse(saved); } catch { this.clearSession(); }
    }
  }

  // ─── Getters ────────────────────────────────────────────────────

  get currentUser(): User | null { return this._currentUser; }

  get token(): string | null { return localStorage.getItem(TOKEN_KEY); }

  get role(): UserRole | null { return this._currentUser?.role ?? null; }

  get isAdmin(): boolean        { return this._currentUser?.role === 'ADMIN'; }
  get isEntrepreneur(): boolean { return this._currentUser?.role === 'ENTREPRENEUR'; }
  get isCoach(): boolean        { return this._currentUser?.role === 'COACH'; }

  get isLoggedIn(): boolean { return !!this.token && !!this._currentUser; }

  get planType(): PlanType | null { return this._currentUser?.planType ?? null; }

  get hasActiveSubscription(): boolean {
    if (!this._currentUser) return false;
    if (this.isCoach || this.isAdmin) return true;
    return this._currentUser.planType !== 'FREE' && this._currentUser.planType !== null;
  }

  canAccess(requiredPlan: PlanType): boolean {
    if (!this._currentUser) return false;
    if (this.isCoach || this.isAdmin) return true;
    const hierarchy: Record<PlanType, number> = { FREE: 1, PREMIUM: 2, INSTITUTIONAL: 3 };
    const userPlan = this._currentUser.planType ?? 'FREE';
    return hierarchy[userPlan] >= hierarchy[requiredPlan];
  }

  getDefaultRoute(): string {
    switch (this._currentUser?.role) {
      case 'ADMIN':        return '/khotwaadmin/dashboard';
      case 'ENTREPRENEUR': return '/entrepreneur/dashboard';
      case 'COACH':        return '/coach/dashboard';
      default:             return '/login';
    }
  }

  // ─── API Calls ──────────────────────────────────────────────────

  login(credentials: LoginRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${API_BASE}/auth/login`, credentials).pipe(
      tap(response => this.handleAuthResponse(response)),
      catchError(err => throwError(() => this.extractError(err)))
    );
  }

  register(payload: RegisterRequest): Observable<UserResponse> {
    return this.http.post<UserResponse>(`${API_BASE}/auth/register`, payload).pipe(
      catchError(err => throwError(() => this.extractError(err)))
    );
  }

  /**
   * Recharge le profil complet depuis le backend (GET /api/users/me).
   * À appeler après le login pour enrichir les données (planType, avatar…).
   */
  refreshProfile(): Observable<UserResponse> {
    return this.http.get<UserResponse>(`${API_BASE}/users/me`).pipe(
      tap(profile => {
        if (this._currentUser) {
          this._currentUser = { ...this._currentUser, ...this.mapUserResponse(profile) };
          localStorage.setItem(USER_KEY, JSON.stringify(this._currentUser));
        }
      }),
      catchError(err => throwError(() => this.extractError(err)))
    );
  }

  logout(): void {
    this.clearSession();
    this.router.navigateByUrl('/login');
  }

  // ─── Private helpers ────────────────────────────────────────────

  private handleAuthResponse(response: AuthResponse): void {
    localStorage.setItem(TOKEN_KEY, response.token);
    // Construit un User minimal depuis AuthResponse ; refreshProfile() le complètera
    this._currentUser = {
      idUser:             response.idUser,
      firstName:          '',
      lastName:           '',
      emailAddress:       response.emailAddress,
      role:               response.role,
      planType:           null,
      pendingPlan:        null,
      avatar:             null,
      startup:            null,
      phoneNumber:        null,
      mustChangePassword: response.mustChangePassword,
    };
    localStorage.setItem(USER_KEY, JSON.stringify(this._currentUser));
  }

  private mapUserResponse(u: UserResponse): Partial<User> {
    return {
      idUser:             u.idUser,
      firstName:          u.firstName,
      lastName:           u.lastName,
      emailAddress:       u.emailAddress,
      role:               u.role,
      planType:           u.planType,
      pendingPlan:        u.pendingPlan,
      avatar:             u.avatar,
      startup:            u.startup,
      phoneNumber:        u.phoneNumber,
      mustChangePassword: u.mustChangePassword,
    };
  }

  private clearSession(): void {
    this._currentUser = null;
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  }


private extractError(err: any): string {
  console.log('STATUS:', err?.status);
  console.log('ERROR BODY:', err?.error);
  console.log('FULL ERROR:', err);

  if (typeof err?.error === 'string') return err.error;

  if (err?.error?.message) return err.error.message;

  if (err?.error?.errors) {
    return Object.values(err.error.errors).join(' | ');
  }

  if (Array.isArray(err?.error)) {
    return err.error.join(' | ');
  }

  if (err?.status === 400) return 'Données invalides envoyées au backend.';
  if (err?.status === 401) return 'Email ou mot de passe incorrect.';

  return 'Une erreur est survenue.';
}  }
