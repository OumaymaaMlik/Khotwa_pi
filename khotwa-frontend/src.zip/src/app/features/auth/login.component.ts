import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { UserRole } from '../../core/models/user.model';
import { switchMap } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  mode: 'signin' | 'signup' = 'signin';

  // Sign-in fields
  emailAddress    = '';
  password = '';

  // Sign-up fields
  firstName    = '';
  lastName     = '';
  selectedRole: UserRole = 'ENTREPRENEUR';

  error   = '';
  loading = false;

  roles = [
    { role: 'ENTREPRENEUR' as UserRole, label: 'Entrepreneur', color: '#2ABFBF', icon: '🚀' },
    { role: 'COACH'        as UserRole, label: 'Coach / Mentor', color: '#7C5CBF', icon: '🎯' },
  ];

  constructor(private auth: AuthService, private router: Router) {}

  signIn(): void {
    this.error = '';
    if (!this.emailAddress || !this.password) {
      this.error = 'Veuillez remplir tous les champs.';
      return;
      console.log(this.emailAddress, this.password);
    }

    this.loading = true;

    // 1) Login → obtenir le token
    // 2) Puis recharger le profil complet (planType, avatar, etc.)
    this.auth.login({ emailAddress: this.emailAddress, password: this.password }).pipe(
      switchMap(() => this.auth.refreshProfile())
    ).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigateByUrl(this.auth.getDefaultRoute());
      },
      error: (msg: string) => {
        this.loading = false;
        this.error = msg;
      },
    });
  }

  signUp(): void {
    this.error = '';
    if (!this.emailAddress || !this.password || !this.firstName || !this.lastName) {
      this.error = 'Veuillez remplir tous les champs.';
      return;
            console.log(this.emailAddress, this.password);

      
    }

    this.loading = true;

    // 1) Register → 2) Login automatique → 3) Charger le profil
    this.auth.register({
      firstName:    this.firstName,
      lastName:     this.lastName,
      emailAddress: this.emailAddress,
      password:     this.password,
      role:         this.selectedRole,
    }).pipe(
      switchMap(() => this.auth.login({ emailAddress: this.emailAddress, password: this.password })),
      switchMap(() => this.auth.refreshProfile())
    ).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigateByUrl(this.auth.getDefaultRoute());
      },
      error: (msg: string) => {
        this.loading = false;
        this.error = msg;
      },
    });
  }
}