import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../core/services/auth.service';
import { EvenementService } from '../../../core/services/events.service';
import { ReservationService } from '../../../core/services/reservations.service';
import { Evenement } from '../../../core/models/evenement.model';
import { Reservation } from '../../../core/models/Reservations.model';
import { PlanType } from '../../../core/models/user.model';

@Component({
  selector: 'app-entrepreneur-evenements',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EntrepreneurEvenementsComponent implements OnInit {

  /* ---- UI state ---- */
  isPlanSelected    = false;
  selectedPlanView: PlanType | null = null;
  viewMode: 'grid' | 'calendar' = 'grid';
  upgradeToastPlan: string | null = null;

  /* ---- Data ---- */
  events:         Evenement[]   = [];
  filteredEvents: Evenement[]   = [];
  bookings:       Reservation[] = [];
  recentBookings: Evenement[]   = [];

  /* ---- Modals ---- */
  selectedEvent: Evenement | null = null;
  bookingTarget: Evenement | null = null;

  /* ---- Filters ---- */
  searchText:  string = '';
  monthFilter: string = 'ALL';
  typeFilter:  string = 'ALL';

  /* ---- Calendar ---- */
  calendarYear:   number = new Date().getFullYear();
  calendarMonth:  number = new Date().getMonth();
  calendarDays:   (number | null)[] = [];
  calendarEvents: { [day: number]: Evenement[] } = {};
  calendarDayDetails: Evenement[] | null = null;
  calendarDetailDay:  number | null = null;

  months = [
    'January','February','March','April','May','June',
    'July','August','September','October','November','December'
  ];
  monthsFr = [
    'Janvier','Février','Mars','Avril','Mai','Juin',
    'Juillet','Août','Septembre','Octobre','Novembre','Décembre'
  ];
  weekDays = ['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'];

  constructor(
    public  auth:       AuthService,
    private evSvc:      EvenementService,
    private bookingSvc: ReservationService
  ) {}

  ngOnInit(): void {
    const userId = this.auth.currentUser?.idUser;
    if (userId) {
      this.bookingSvc.getReservationsByUser(userId).subscribe({
        next:  data => this.bookings = data,
        error: err  => console.error('Erreur réservations', err)
      });
    }
    this.isPlanSelected   = false;
    this.selectedPlanView = null;
  }

  /* ====================================================
      PLAN SELECTION
     ==================================================== */
showUpgradeOverlay = false;
upgradePlan: 'PREMIUM' | 'INSTITUTIONAL' | null = null;

selectPlanView(plan: PlanType): void {
  // On vérifie si l'utilisateur a le droit d'accéder à ce plan
  const isLocked = this.isLockedPlan(plan);

  /*if (isLocked) {
    // Si c'est verrouillé, on affiche le message d'upgrade
    this.showUpgradeToast(plan);
    // Optionnel : vous pouvez choisir de ne PAS charger les événements 
    // ou de rediriger vers la page de paiement ici.
    return; 
}*/  

this.selectedPlanView = plan;
  this.isPlanSelected   = true;
  this.resetFiltersOnly();
  this.viewMode         = 'grid';
  
  // On charge les événements du plan sélectionné
  this.loadEventsByPlan(plan);
} 

private loadEventsByPlan(plan: PlanType): void { {
  const userPlan = this.auth.currentUser?.planType;

  // On récupère tout pour être sûr de ne rien rater
  this.evSvc.getAll().subscribe({
    next: (data: Evenement[]) => {
      let filtered: Evenement[] = [];

      if (plan === 'FREE') {
        // Uniquement le contenu gratuit
        filtered = data.filter(e => e.planType === 'FREE');
      } 
      else if (plan === 'PREMIUM') {
        // C'est ici que ça se passe : On affiche FREE + PREMIUM
        filtered = data.filter(e => e.planType === 'FREE' || e.planType === 'PREMIUM');
      } 
      else if (plan === 'INSTITUTIONAL') {
        // Uniquement le contenu institutionnel
        filtered = data.filter(e => e.planType === 'INSTITUTIONAL');
      }

      this.setEvents(filtered);
      console.log(`Affichage pour le plan ${plan}:`, filtered);
    },
    error: err => console.error('Erreur lors du chargement des événements', err)
  });
}

      
  }

  private setEvents(data: Evenement[]): void {
    this.events         = data;
    this.filteredEvents = data;
    this.buildCalendar();
  }

  /* ====================================================
      SEARCH & FILTERS (live, client-side)
     ==================================================== */

  applyFilters(): void {
    let result = [...this.events];

    if (this.searchText.trim()) {
      const q = this.searchText.trim().toLowerCase();
      result = result.filter(e =>
        e.titre?.toLowerCase().includes(q) ||
        e.intervenant?.toLowerCase().includes(q) ||
        e.description?.toLowerCase().includes(q)
      );
    }

    if (this.monthFilter !== 'ALL') {
      const m = Number(this.monthFilter);
      result = result.filter(e => new Date(e.date).getMonth() + 1 === m);
    }

    if (this.typeFilter !== 'ALL') {
      result = result.filter(e => e.type === this.typeFilter);
    }

    this.filteredEvents = result;
    this.buildCalendar();
  }

  private resetFiltersOnly(): void {
    this.searchText  = '';
    this.monthFilter = 'ALL';
    this.typeFilter  = 'ALL';
  }

  resetFilters(): void {
    this.resetFiltersOnly();
    this.filteredEvents = this.events;
    this.buildCalendar();
  }

  get hasActiveFilters(): boolean {
    return this.searchText.trim() !== '' || this.monthFilter !== 'ALL' || this.typeFilter !== 'ALL';
  }

  /* ====================================================
      BOOKING
     ==================================================== */

  isLocked(_ev: Evenement): boolean { return false; }

  isAlreadyBooked(ev: Evenement): boolean {
    return this.bookings.some(b => b.idEvenement === ev.idEvenement);
  }

  openBookingModal(ev: Evenement): void {
    if (this.isAlreadyBooked(ev) || ev.placesRestantes === 0) return;
    this.bookingTarget = ev;
  }

  confirmBooking(): void {
    const userId = this.auth.currentUser?.idUser;
    const ev = this.bookingTarget;
    if (!userId || !ev) { this.bookingTarget = null; return; }

    this.bookingSvc.addReservation(userId, ev.idEvenement).subscribe({
      next: (r) => {
        this.bookings.push(r);
        this.showToast(ev);
        this.bookingTarget = null;
      },
      error: err => { console.error('Échec réservation', err); this.bookingTarget = null; }
    });
  }

  cancelBooking(ev: Evenement): void {
    const userId = this.auth.currentUser?.idUser;
    if (!userId) return;
    this.bookingSvc.cancelReservationByEvent(userId, ev.idEvenement).subscribe({
      next: () => { this.bookings = this.bookings.filter(b => b.idEvenement !== ev.idEvenement); },
      error: err => console.error('Erreur annulation', err)
    });
  }

  private showToast(ev: Evenement): void {
    this.recentBookings.unshift(ev);
    if (this.recentBookings.length > 3) this.recentBookings.pop();
    setTimeout(() => {
      this.recentBookings = this.recentBookings.filter(b => b.idEvenement !== ev.idEvenement);
    }, 5000);
  }

  /* ====================================================
      CALENDAR
     ==================================================== */

  buildCalendar(): void {
    const year  = this.calendarYear;
    const month = this.calendarMonth;
    const firstDay    = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const startOffset = firstDay === 0 ? 6 : firstDay - 1;

    this.calendarDays = [];
    for (let i = 0; i < startOffset; i++) this.calendarDays.push(null);
    for (let d = 1; d <= daysInMonth; d++) this.calendarDays.push(d);

    this.calendarEvents = {};
    this.filteredEvents.forEach(ev => {
      const d = new Date(ev.date);
      if (d.getFullYear() === year && d.getMonth() === month) {
        const day = d.getDate();
        if (!this.calendarEvents[day]) this.calendarEvents[day] = [];
        this.calendarEvents[day].push(ev);
      }
    });
  }

  prevMonth(): void {
    if (this.calendarMonth === 0) { this.calendarMonth = 11; this.calendarYear--; }
    else this.calendarMonth--;
    this.calendarDayDetails = null;
    this.buildCalendar();
  }

  nextMonth(): void {
    if (this.calendarMonth === 11) { this.calendarMonth = 0; this.calendarYear++; }
    else this.calendarMonth++;
    this.calendarDayDetails = null;
    this.buildCalendar();
  }

  isToday(day: number | null): boolean {
    if (!day) return false;
    const t = new Date();
    return t.getFullYear() === this.calendarYear && t.getMonth() === this.calendarMonth && t.getDate() === day;
  }

  getDayEvents(day: number | null): Evenement[] {
    if (!day) return [];
    return this.calendarEvents[day] || [];
  }

  hasDayBooking(day: number | null): boolean {
    const evs = this.getDayEvents(day);
    if (!evs.length) return false;
    for (const e of evs) { if (this.isAlreadyBooked(e)) return true; }
    return false;
  }

  openDayPopup(day: number | null): void {
    if (!day) return;
    const evs = this.getDayEvents(day);
    if (!evs.length) return;
    this.calendarDetailDay  = day;
    this.calendarDayDetails = evs;
  }

  closeDayPopup(): void {
    this.calendarDayDetails = null;
    this.calendarDetailDay  = null;
  }

  /* ====================================================
      HELPERS
     ==================================================== */

  get currentUserPlan(): PlanType {
    return this.auth.currentUser?.planType ?? 'FREE';
  }

  get planLabel(): string {
    const p = this.selectedPlanView ?? this.currentUserPlan;
    return p === 'FREE' ? 'Free' : p === 'PREMIUM' ? 'Premium' : 'Institutionnel';
  }

  get planDescription(): string {
    const p = this.selectedPlanView ?? this.currentUserPlan;
    return p === 'FREE' ? 'Événements gratuits' : p === 'PREMIUM' ? 'Événements Free & Premium' : 'Événements Institutionnels';
  }

  get planColorClass(): string {
    return (this.selectedPlanView ?? this.currentUserPlan).toLowerCase();
  }

  isLockedPlan(plan: PlanType): boolean {
    if (plan === 'FREE') return false;
    if (plan === 'PREMIUM') return this.currentUserPlan === 'FREE';
    if (plan === 'INSTITUTIONAL') return this.currentUserPlan !== 'INSTITUTIONAL';
    return false;
  }

  showUpgradeToast(plan: string): void {
    this.upgradeToastPlan = plan;
    setTimeout(() => { this.upgradeToastPlan = null; }, 4000);
  }

  openDetails(ev: Evenement): void { this.selectedEvent = ev; }
  closeDetails(): void { this.selectedEvent = null; }
  closeBookingModal(): void { this.bookingTarget = null; }
  switchView(mode: 'grid' | 'calendar'): void {
    this.viewMode = mode;
    if (mode === 'calendar') this.buildCalendar();
  }
  upgrade(): void { window.location.href = '/entrepreneur/pricing'; }
}
