package tn.khotwa.controller.EvenementController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tn.khotwa.entity.evenement.Reservation;
import tn.khotwa.service.EvenementService.IReservationService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/reservation")
@CrossOrigin(origins = "http://localhost:4200")
public class ReservationController {

    @Autowired
    private IReservationService reservationService;

    // ── Réservation ───────────────────────────────────────────────────────────
    // Gère automatiquement CONFIRMED ou WAITLIST selon les places disponibles
    @PostMapping("/add/{idUser}/{idEvenement}")
    public ResponseEntity<?> addReservation(
            @PathVariable Long idUser,
            @PathVariable Long idEvenement) {
        try {
            Reservation r = reservationService.addReservation(idUser, idEvenement);
            return ResponseEntity.ok(Map.of(
                    "status",      r.getStatus().toString(),
                    "reservation", r,
                    // Message clair pour le frontend
                    "message", r.getStatus().toString().equals("WAITLIST")
                            ? "Event is full. You are on the waiting list at position #" + r.getWaitlistPosition()
                            : "Reservation confirmed!"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // ── Annulation ────────────────────────────────────────────────────────────
    @PutMapping("/cancel/{idReservation}")
    public ResponseEntity<?> cancelReservation(@PathVariable Long idReservation) {
        try {
            reservationService.cancelReservation(idReservation);
            return ResponseEntity.ok(Map.of("message", "Reservation cancelled."));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PutMapping("/cancel/user/{idUser}/event/{idEvenement}")
    public ResponseEntity<?> cancelByUserAndEvent(
            @PathVariable Long idUser,
            @PathVariable Long idEvenement) {
        try {
            reservationService.cancelByUserAndEvent(idUser, idEvenement);
            return ResponseEntity.ok(Map.of("message", "Reservation cancelled."));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // ── Liste d'attente ───────────────────────────────────────────────────────
    @GetMapping("/waitlist/event/{idEvenement}")
    public ResponseEntity<List<Reservation>> getWaitlist(@PathVariable Long idEvenement) {
        return ResponseEntity.ok(reservationService.getWaitlistByEvent(idEvenement));
    }

    // ── QR Code ───────────────────────────────────────────────────────────────

    // L'entrepreneur récupère son QR code (image base64) + lienMeet + titre
    // Scanner le QR → ouvre directement Teams/Meet sur le téléphone
    @GetMapping(value = "/qr/{idReservation}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getQrCode(@PathVariable Long idReservation) {
        try {
            Map<String, String> result = reservationService.generateQrCode(idReservation);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // L'intervenant scanne le QR → marque ATTENDED
    @PostMapping("/scan")
    public ResponseEntity<Map<String, Object>> scanQr(@RequestBody Map<String, String> body) {
        try {
            String token = body.get("qrToken");
            Map<String, Object> result = reservationService.scanQrCode(token);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "error", e.getMessage()
            ));
        }
    }

    // ── Lectures ──────────────────────────────────────────────────────────────
    @GetMapping("/all")
    public List<Reservation> getAllReservations() {
        return reservationService.getAllReservations();
    }

    @GetMapping("/user/{idUser}")
    public List<Reservation> getReservationsByUser(@PathVariable Long idUser) {
        return reservationService.getReservationsByUser(idUser);
    }

    @GetMapping("/event/{idEvenement}")
    public List<Reservation> getReservationsByEvent(@PathVariable Long idEvenement) {
        return reservationService.getReservationsByEvent(idEvenement);
    }
}