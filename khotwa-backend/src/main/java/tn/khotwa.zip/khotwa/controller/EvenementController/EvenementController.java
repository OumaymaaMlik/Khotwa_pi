package tn.khotwa.controller.EvenementController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tn.khotwa.entity.evenement.Evenement;
import tn.khotwa.enums.EventsEnums.EvenementStatus;
import tn.khotwa.service.EvenementService.IEvenementService;
import tn.khotwa.service.EvenementService.QrMeetService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/evenement")
@CrossOrigin(origins = "http://localhost:4200")
public class EvenementController {

    @Autowired
    private IEvenementService evenementService;

    @Autowired
    private QrMeetService qrMeetService;

    @PostMapping(value = "/add", produces = MediaType.APPLICATION_JSON_VALUE)
    public Evenement addEvenement(@RequestBody Evenement evenement) {
        return evenementService.addEvenement(evenement);
    }

    @PutMapping("/update/{idEvenement}")
    public Evenement updateEvenement(@PathVariable Long idEvenement,
                                     @RequestBody Evenement evenement) {
        return evenementService.updateEvenement(idEvenement, evenement);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteEvenement(@PathVariable Long id) {
        evenementService.deleteEvenement(id);
    }

    @GetMapping("/get/{id}")
    public Evenement getEvenementById(@PathVariable Long id) {
        return evenementService.findEvenementById(id);
    }

    @GetMapping("/getAll")
    public List<Evenement> getAllEvenements() {
        return evenementService.findAllEvenements();
    }

    @PostMapping("/participer/{idEvenement}/{idUser}")
    public Evenement addParticipant(@PathVariable Long idEvenement,
                                    @PathVariable Long idUser) {
        return evenementService.addParticipant(idEvenement, idUser);
    }

    @PutMapping("/update-status/{idEvenement}")
    public void updateStatus(@PathVariable Long idEvenement,
                             @RequestParam EvenementStatus statut) {
        evenementService.changeStatus(idEvenement, statut);
    }

    @GetMapping("/admin-events")
    public List<Evenement> getAdminEvents() {
        return evenementService.findAdminEvents();
    }

    @GetMapping("/my-plan/{idUser}")
    public List<Evenement> getMyEvents(@PathVariable Long idUser) {
        return evenementService.getVisibleEventsForUser(idUser);
    }

    @GetMapping("/my-plan/strict/{idUser}")
    public List<Evenement> getStrictEvents(@PathVariable Long idUser) {
        return evenementService.getStrictEventsForUser(idUser);
    }

    @GetMapping("/free/all")
    public List<Evenement> getAllFreeEvents() {
        return evenementService.getAllFreeEvents();
    }

    @GetMapping("/freeEvenets/search")
    public List<Evenement> searchFreeEvents(
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) String type) {
        return evenementService.searchFreeEvents(month, type);
    }

    // ── QR Code Meet ─────────────────────────────────────────────────────────
    // Généré par le coach : encode le lienMeet de l'événement dans un QR code.
    // L'entrepreneur scanne avec son téléphone → redirigé directement vers le Meet.
    // GET /evenement/{idEvenement}/qr-meet
    @GetMapping(value = "/{idEvenement}/qr-meet", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getQrMeet(@PathVariable Long idEvenement) {
        try {
            Evenement ev = evenementService.findEvenementById(idEvenement);

            if (ev.getLienMeet() == null || ev.getLienMeet().isBlank()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "No meet link configured for this event."));
            }

            String qrBase64 = qrMeetService.generateQrForUrl(ev.getLienMeet());

            return ResponseEntity.ok(Map.of(
                    "qrCode",   qrBase64,          // image PNG base64 — affiché côté coach
                    "lienMeet", ev.getLienMeet(),   // lien brut — fallback bouton direct
                    "titre",    ev.getTitre()
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}