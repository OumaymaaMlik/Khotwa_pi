package tn.khotwa.service.EvenementService;

import tn.khotwa.entity.evenement.Reservation;
import java.util.List;
import java.util.Map;

public interface IReservationService {

    // ── Réservation de base ───────────────────────────────────────────────────
    Reservation addReservation(Long userId, Long eventId);
    void cancelReservation(Long reservationId);
    void cancelByUserAndEvent(Long idUser, Long idEvenement);

    // ── Lecture ───────────────────────────────────────────────────────────────
    List<Reservation> getReservationsByUser(Long userId);
    List<Reservation> getReservationsByEvent(Long eventId);
    List<Reservation> getAllReservations();

    // ── Liste d'attente ───────────────────────────────────────────────────────
    List<Reservation> getWaitlistByEvent(Long eventId);

    // ── QR Code présence ─────────────────────────────────────────────────────
    // Générer le QR code d'une réservation (retourne qrCode + lienMeet + titre)
    // Le QR encode le lienMeet → l'entrepreneur scanne → Teams/Meet s'ouvre
    Map<String, String> generateQrCode(Long reservationId);

    // Scanner le QR code → marquer ATTENDED
    Map<String, Object> scanQrCode(String qrToken);
}