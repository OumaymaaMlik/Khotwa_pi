package tn.khotwa.service.EvenementService;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tn.khotwa.entity.UserEntities.User;
import tn.khotwa.entity.evenement.Evenement;
import tn.khotwa.entity.evenement.Reservation;
import tn.khotwa.enums.EventsEnums.EvenementType;
import tn.khotwa.enums.EventsEnums.ReservationsStatus;
import tn.khotwa.enums.SubscriptionEnums.PlanType;
import tn.khotwa.repository.EvenementRepo.EvenementRepository;
import tn.khotwa.repository.EvenementRepo.ReservationRepository;
import tn.khotwa.repository.UserRepo.UserRepository;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class ReservationService implements IReservationService {
    private static final int CANCELLATION_DEADLINE_HOURS = 24;

    @Autowired private ReservationRepository reservationRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private EvenementRepository evenementRepository;
    @Autowired private EmailServiceEvents emailService;

    // ── Limites par plan et par type (par mois) ───────────────────────────────
    // FREE      : max 2 réservations du même type/mois
    // PREMIUM   : max 5
    // INSTITUTIONAL : illimité
    private int getMonthlyLimit(PlanType plan) {
        return switch (plan) {
            case FREE          -> 2;
            case PREMIUM       -> 5;
            case INSTITUTIONAL -> Integer.MAX_VALUE;
        };
    }

    // ─────────────────────────────────────────────────────────────────────────
    // RÉSERVER un événement
    // Logique :
    //   1. Vérifier que l'user n'est pas déjà inscrit/waitlist
    //   2. Vérifier la limite mensuelle par type selon le plan
    //   3a. Si des places → CONFIRMED + QR code généré
    //   3b. Si complet → WAITLIST + email d'ajout en attente
    // ─────────────────────────────────────────────────────────────────────────
    @Override
    @Transactional
    public Reservation addReservation(Long idUser, Long idEvenement) {
        User user = userRepository.findById(idUser)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Evenement event = evenementRepository.findById(idEvenement)
                .orElseThrow(() -> new RuntimeException("Event not found"));

        // 1. Déjà inscrit ou en waitlist ?
        boolean alreadyExists =
                reservationRepository.existsByUser_IdUserAndEvenement_IdEvenementAndStatus(
                        idUser, idEvenement, ReservationsStatus.CONFIRMED) ||
                        reservationRepository.existsByUser_IdUserAndEvenement_IdEvenementAndStatus(
                                idUser, idEvenement, ReservationsStatus.WAITLIST);

        if (alreadyExists) {
            throw new RuntimeException("You are already registered or on the waitlist for this event.");
        }

        // 2. Vérifier la limite mensuelle par type
        PlanType plan = user.getPlanType() != null ? user.getPlanType() : PlanType.FREE;
        int limit = getMonthlyLimit(plan);

        LocalDateTime startOfMonth = LocalDate.now().withDayOfMonth(1).atStartOfDay();
        LocalDateTime startOfNextMonth = startOfMonth.plusMonths(1);

        long countThisMonth = reservationRepository.countConfirmedByUserAndTypeThisMonth(
                idUser, event.getType(), startOfMonth, startOfNextMonth);

        if (countThisMonth >= limit) {
            throw new RuntimeException(
                    "Monthly limit reached: you can only book " + limit +
                            " " + event.getType() + " event(s) per month with your " + plan + " plan."
            );
        }

        // 3. Place disponible ?
        if (event.getPlacesRestantes() > 0) {
            // ── CAS A : CONFIRMED ────────────────────────────────────────────
            Reservation reservation = new Reservation();
            reservation.setUser(user);
            reservation.setEvenement(event);
            reservation.setDateReservation(LocalDateTime.now());
            reservation.setStatus(ReservationsStatus.CONFIRMED);
            reservation.setQrToken(UUID.randomUUID().toString()); // QR token unique

            event.setPlacesRestantes(event.getPlacesRestantes() - 1);
            evenementRepository.save(event);

            return reservationRepository.save(reservation);

        } else {
            // ── CAS B : WAITLIST ─────────────────────────────────────────────
            int nextPosition = reservationRepository.findMaxWaitlistPosition(event) + 1;

            Reservation waitlistReservation = new Reservation();
            waitlistReservation.setUser(user);
            waitlistReservation.setEvenement(event);
            waitlistReservation.setDateReservation(LocalDateTime.now());
            waitlistReservation.setStatus(ReservationsStatus.WAITLIST);
            waitlistReservation.setWaitlistPosition(nextPosition);

            Reservation saved = reservationRepository.save(waitlistReservation);

            // Email : "vous êtes en liste d'attente position #N"
            try { emailService.sendWaitlistAdded(saved); } catch (Exception ignored) {}

            return saved;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ANNULER une réservation
    // Si l'annulation libère une place → promouvoir le 1er de la waitlist
    // ─────────────────────────────────────────────────────────────────────────
    @Override
    @Transactional
    public void cancelReservation(Long idReservation) {
        Reservation reservation = reservationRepository.findById(idReservation)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        if (ReservationsStatus.CANCELLED.equals(reservation.getStatus())) {
            throw new RuntimeException("Reservation already cancelled.");
        }
        if (ReservationsStatus.ATTENDED.equals(reservation.getStatus())) {
            throw new RuntimeException("Attended reservations cannot be cancelled.");
        }

        enforceCancellationWindow(reservation.getEvenement());
        boolean wasConfirmed = ReservationsStatus.CONFIRMED.equals(reservation.getStatus());

        reservation.setStatus(ReservationsStatus.CANCELLED);
        reservation.setWaitlistPosition(null);
        reservationRepository.save(reservation);

        // Libérer la place seulement si c'était CONFIRMED (pas WAITLIST)
        if (wasConfirmed) {
            Evenement event = reservation.getEvenement();
            event.setPlacesRestantes(event.getPlacesRestantes() + 1);
            evenementRepository.save(event);
            promoteFromWaitlist(event);
        }
    }

    @Override
    @Transactional
    public void cancelByUserAndEvent(Long idUser, Long idEvenement) {
        Reservation reservation = reservationRepository
                .findFirstByUser_IdUserAndEvenement_IdEvenementAndStatusInOrderByDateReservationDesc(
                        idUser,
                        idEvenement,
                        Arrays.asList(ReservationsStatus.CONFIRMED, ReservationsStatus.WAITLIST, ReservationsStatus.PENDING)
                )
                .orElseThrow(() -> new RuntimeException("Active reservation not found for this user and event."));

        boolean wasConfirmed = ReservationsStatus.CONFIRMED.equals(reservation.getStatus());
        enforceCancellationWindow(reservation.getEvenement());

        reservation.setStatus(ReservationsStatus.CANCELLED);
        reservation.setWaitlistPosition(null);
        reservationRepository.save(reservation);

        if (wasConfirmed) {
            Evenement event = reservation.getEvenement();
            event.setPlacesRestantes(event.getPlacesRestantes() + 1);
            evenementRepository.save(event);
            promoteFromWaitlist(event);
        }
    }

    private void enforceCancellationWindow(Evenement event) {
        LocalTime eventTime = event.getHeure() != null ? event.getHeure() : LocalTime.MIDNIGHT;
        LocalDateTime eventDateTime = LocalDateTime.of(event.getDate(), eventTime);
        LocalDateTime cancellationDeadline = eventDateTime.minusHours(CANCELLATION_DEADLINE_HOURS);
        if (LocalDateTime.now().isAfter(cancellationDeadline)) {
            throw new RuntimeException(
                    "Cancellations are only allowed up to " + CANCELLATION_DEADLINE_HOURS + " hours before the event."
            );
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Promouvoir le premier de la waitlist → CONFIRMED
    // ─────────────────────────────────────────────────────────────────────────
    private void promoteFromWaitlist(Evenement event) {
        List<Reservation> waitlist = reservationRepository.findWaitlistByEvent(event);
        if (waitlist.isEmpty()) return;

        Reservation first = waitlist.get(0);
        first.setStatus(ReservationsStatus.CONFIRMED);
        first.setWaitlistPosition(null);
        first.setQrToken(UUID.randomUUID().toString()); // QR token généré à la confirmation

        event.setPlacesRestantes(event.getPlacesRestantes() - 1);
        evenementRepository.save(event);
        reservationRepository.save(first);

        // Renuméroter les suivants
        for (int i = 1; i < waitlist.size(); i++) {
            waitlist.get(i).setWaitlistPosition(i);
            reservationRepository.save(waitlist.get(i));
        }

        // Email de confirmation de place
        try { emailService.sendWaitlistConfirmation(first); } catch (Exception ignored) {}
    }

    // ─────────────────────────────────────────────────────────────────────────
    // QR CODE — générer l'image en base64 pour une réservation CONFIRMED
    // Le QR encode le lienMeet (Teams/Meet) → l'entrepreneur scanne → réunion ouverte
    // Retourne aussi lienMeet (fallback bouton direct) et titre de l'événement
    // ─────────────────────────────────────────────────────────────────────────
    @Override
    public Map<String, String> generateQrCode(Long reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        if (!ReservationsStatus.CONFIRMED.equals(reservation.getStatus())) {
            throw new RuntimeException("QR code only available for CONFIRMED reservations.");
        }

        String meetUrl = reservation.getEvenement().getLienMeet();
        if (meetUrl == null || meetUrl.isBlank()) {
            throw new RuntimeException("No meet link configured for this event.");
        }

        if (!meetUrl.startsWith("http://") && !meetUrl.startsWith("https://")) {
            meetUrl = "https://" + meetUrl;
        }

        try {
            QRCodeWriter writer = new QRCodeWriter();
            BitMatrix matrix = writer.encode(meetUrl, BarcodeFormat.QR_CODE, 250, 250);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(matrix, "PNG", out);
            String qrBase64 = "data:image/png;base64," + Base64.getEncoder().encodeToString(out.toByteArray());

            return Map.of(
                    "qrCode",   qrBase64,
                    "lienMeet", meetUrl,
                    "titre",    reservation.getEvenement().getTitre()
            );
        } catch (Exception e) {
            throw new RuntimeException("QR code generation failed: " + e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // QR CODE — scanner → marquer ATTENDED
    // Appelé par l'intervenant depuis son interface
    // ─────────────────────────────────────────────────────────────────────────
    @Override
    @Transactional
    public Map<String, Object> scanQrCode(String qrToken) {
        Reservation reservation = reservationRepository.findByQrToken(qrToken)
                .orElseThrow(() -> new RuntimeException("Invalid QR code."));

        if (ReservationsStatus.ATTENDED.equals(reservation.getStatus())) {
            return Map.of(
                    "success", false,
                    "message", "Already marked as attended.",
                    "user", reservation.getUser().getFirstName() + " " + reservation.getUser().getLastName(),
                    "event", reservation.getEvenement().getTitre()
            );
        }

        if (!ReservationsStatus.CONFIRMED.equals(reservation.getStatus())) {
            throw new RuntimeException("This reservation is not CONFIRMED.");
        }

        reservation.setStatus(ReservationsStatus.ATTENDED);
        reservation.setAttendedAt(LocalDateTime.now());
        reservationRepository.save(reservation);

        try { emailService.sendAttendanceConfirmed(reservation); } catch (Exception ignored) {}

        return Map.of(
                "success", true,
                "message", "Attendance confirmed!",
                "user", reservation.getUser().getFirstName() + " " + reservation.getUser().getLastName(),
                "event", reservation.getEvenement().getTitre(),
                "attendedAt", reservation.getAttendedAt().toString()
        );
    }

    // ── Lectures ──────────────────────────────────────────────────────────────
    @Override
    public List<Reservation> getReservationsByUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return reservationRepository.findByUser(user);
    }

    @Override
    public List<Reservation> getReservationsByEvent(Long eventId) {
        Evenement event = evenementRepository.findById(eventId)
                .orElseThrow(() -> new RuntimeException("Event not found"));
        return reservationRepository.findByEvenement(event);
    }

    @Override
    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    @Override
    public List<Reservation> getWaitlistByEvent(Long eventId) {
        Evenement event = evenementRepository.findById(eventId)
                .orElseThrow(() -> new RuntimeException("Event not found"));
        return reservationRepository.findWaitlistByEvent(event);
    }
}

















/*package tn.khotwa.service.EvenementService;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tn.khotwa.entity.UserEntities.User;
import tn.khotwa.entity.evenement.Evenement;
import tn.khotwa.entity.evenement.Reservation;
import tn.khotwa.enums.EventsEnums.ReservationsStatus;
import tn.khotwa.repository.EvenementRepo.EvenementRepository;
import tn.khotwa.repository.EvenementRepo.ReservationRepository;
import tn.khotwa.repository.UserRepo.UserRepository;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReservationService implements IReservationService {

    @Autowired
    private ReservationRepository reservationRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private EvenementRepository evenementRepository;


    @Override
    @Transactional
    public Reservation addReservation(Long idUser, Long idEvenement) {
        User user = userRepository.findById(idUser).orElseThrow(() -> new RuntimeException("User not found"));
        Evenement event = evenementRepository.findById(idEvenement).orElseThrow(() -> new RuntimeException("Event not found"));

        if (event.getPlacesRestantes() <= 0) {
            throw new RuntimeException("No available spots");
        }

        Reservation reservation = new Reservation();
        reservation.setUser(user);
        reservation.setEvenement(event);
        reservation.setDateReservation(LocalDateTime.now());
        reservation.setStatus(ReservationsStatus.CONFIRMED);

        event.setPlacesRestantes(event.getPlacesRestantes() - 1);
        evenementRepository.save(event);

        return reservationRepository.save(reservation);
    }

    @Override
    @Transactional
    public void cancelReservation(Long idReservation) {
        Reservation reservation = reservationRepository.findById(idReservation)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        reservation.setStatus(ReservationsStatus.CANCELLED);
        reservation.getEvenement().setPlacesRestantes(reservation.getEvenement().getPlacesRestantes() + 1);

        evenementRepository.save(reservation.getEvenement());
        reservationRepository.save(reservation);
    }

    @Override
    public List<Reservation> getReservationsByUser(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        return reservationRepository.findByUser(user);
    }

    @Override
    public List<Reservation> getReservationsByEvent(Long eventId) {
        Evenement event = evenementRepository.findById(eventId).orElseThrow(() -> new RuntimeException("Event not found"));
        return reservationRepository.findByEvenement(event);
    }

    @Override
    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    @Override
    @Transactional
    public void cancelByUserAndEvent(Long idUser, Long idEvenement) {
        Reservation reservation = reservationRepository
                .findByUser_IdUserAndEvenement_IdEvenement(idUser, idEvenement)
                .orElseThrow(() -> new RuntimeException("Réservation introuvable pour cet utilisateur et cet événement"));
        reservation.setStatus(ReservationsStatus.CANCELLED);
        reservationRepository.save(reservation);
    }


}*/