package tn.khotwa.dto.user;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record RegisterRequest(
        @NotBlank(message = "First name is required.")
        String firstName,

        @NotBlank(message = "Last name is required.")
        String lastName,

        @Email(message = "Email address must be valid.")
        @NotBlank(message = "Email address is required.")
        String emailAddress,

        @NotBlank(message = "Password is required.")
        @Size(min = 8, message = "Password must be at least 8 characters long.")
        String password,

        String role,
        String avatar,
        String phoneNumber,
        String startup
) {
}